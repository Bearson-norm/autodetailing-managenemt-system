import React, { createContext, useContext, useState, useEffect } from 'react';

export type UserRole = 'consumer' | 'admin' | 'worker';

export interface User {
  id: string;
  username: string;
  role: UserRole;
  name: string;
  phone?: string;
  language: 'id' | 'en';
}

export type TransactionStatus = 'received' | 'ordered' | 'finished';

export interface Transaction {
  id: string;
  orderNumber: string;
  consumerId: string;
  consumerName: string;
  status: TransactionStatus;
  date: string;
  name: string;
  address: string;
  location?: string;
  whatsapp: string;
  carBrand: string;
  carYear: string;
  carColor: string;
  selectedPackage: 'interior' | 'exterior' | 'complete';
  currentSeat: string;
  hasStain: boolean;
  workplaceAvailable: boolean;
  canopy: boolean;
  parking: boolean;
  waterElectricity: boolean;
  audioSystem: string;
  specialComplaints: string;
  createdAt: string;
}

export interface WorkOrder {
  id: string;
  workOrderNumber: string;
  transactionId: string;
  workerId: string;
  workerName: string;
  status: 'assigned' | 'finished';
  documentation: string[];
  createdAt: string;
}

interface AppContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  users: User[];
  addWorker: (username: string, password: string, name: string) => void;
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id' | 'orderNumber' | 'createdAt'>) => string;
  updateTransactionStatus: (id: string, status: TransactionStatus) => void;
  workOrders: WorkOrder[];
  addWorkOrder: (transactionId: string, workerId: string) => string;
  updateWorkOrder: (id: string, documentation: string[]) => void;
  finishWorkOrder: (id: string) => void;
  login: (username: string, password: string) => User | null;
  logout: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Mock initial data
const initialUsers: User[] = [
  { id: '1', username: 'consumer1', role: 'consumer', name: 'John Doe', phone: '081234567890', language: 'id' },
  { id: '2', username: 'admin1', role: 'admin', name: 'Admin User', language: 'id' },
  { id: '3', username: 'worker1', role: 'worker', name: 'Worker One', language: 'id' },
];

const mockPasswords: Record<string, string> = {
  'consumer1': 'consumer123',
  'admin1': 'admin123',
  'worker1': 'worker123',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [passwords, setPasswords] = useState<Record<string, string>>(mockPasswords);

  // Load from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    const storedUsers = localStorage.getItem('users');
    const storedTransactions = localStorage.getItem('transactions');
    const storedWorkOrders = localStorage.getItem('workOrders');
    const storedPasswords = localStorage.getItem('passwords');

    if (storedUser) setCurrentUser(JSON.parse(storedUser));
    if (storedUsers) setUsers(JSON.parse(storedUsers));
    if (storedTransactions) setTransactions(JSON.parse(storedTransactions));
    if (storedWorkOrders) setWorkOrders(JSON.parse(storedWorkOrders));
    if (storedPasswords) setPasswords(JSON.parse(storedPasswords));
  }, []);

  // Save to localStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('currentUser');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('workOrders', JSON.stringify(workOrders));
  }, [workOrders]);

  useEffect(() => {
    localStorage.setItem('passwords', JSON.stringify(passwords));
  }, [passwords]);

  const login = (username: string, password: string): User | null => {
    if (passwords[username] === password) {
      const user = users.find(u => u.username === username);
      if (user) {
        setCurrentUser(user);
        return user;
      }
    }
    return null;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const addWorker = (username: string, password: string, name: string) => {
    const newWorker: User = {
      id: Date.now().toString(),
      username,
      role: 'worker',
      name,
      language: 'id',
    };
    setUsers([...users, newWorker]);
    setPasswords({ ...passwords, [username]: password });
  };

  const addTransaction = (transaction: Omit<Transaction, 'id' | 'orderNumber' | 'createdAt'>): string => {
    const orderNumber = `ORD-${Date.now()}`;
    const newTransaction: Transaction = {
      ...transaction,
      id: Date.now().toString(),
      orderNumber,
      status: 'received',
      createdAt: new Date().toISOString(),
    };
    setTransactions([...transactions, newTransaction]);
    return orderNumber;
  };

  const updateTransactionStatus = (id: string, status: TransactionStatus) => {
    setTransactions(transactions.map(t => 
      t.id === id ? { ...t, status } : t
    ));
  };

  const addWorkOrder = (transactionId: string, workerId: string): string => {
    const workOrderNumber = `WO-${Date.now()}`;
    const worker = users.find(u => u.id === workerId);
    const newWorkOrder: WorkOrder = {
      id: Date.now().toString(),
      workOrderNumber,
      transactionId,
      workerId,
      workerName: worker?.name || 'Unknown',
      status: 'assigned',
      documentation: [],
      createdAt: new Date().toISOString(),
    };
    setWorkOrders([...workOrders, newWorkOrder]);
    
    // Update transaction status to ordered
    updateTransactionStatus(transactionId, 'ordered');
    
    return workOrderNumber;
  };

  const updateWorkOrder = (id: string, documentation: string[]) => {
    setWorkOrders(workOrders.map(wo => 
      wo.id === id ? { ...wo, documentation } : wo
    ));
  };

  const finishWorkOrder = (id: string) => {
    const workOrder = workOrders.find(wo => wo.id === id);
    if (workOrder) {
      // Update work order status
      setWorkOrders(workOrders.map(wo => 
        wo.id === id ? { ...wo, status: 'finished' } : wo
      ));
      
      // Update transaction status to finished
      updateTransactionStatus(workOrder.transactionId, 'finished');
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        users,
        addWorker,
        transactions,
        addTransaction,
        updateTransactionStatus,
        workOrders,
        addWorkOrder,
        updateWorkOrder,
        finishWorkOrder,
        login,
        logout,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};
