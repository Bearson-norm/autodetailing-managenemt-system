import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { LoginPage } from './components/LoginPage';
import { Sidebar } from './components/Sidebar';
import { Toaster } from './components/ui/sonner';
import { motion, AnimatePresence } from 'motion/react';

// Consumer Components
import { ConsumerHome } from './components/consumer/ConsumerHome';
import { ConsumerHistory } from './components/consumer/ConsumerHistory';
import { ConsumerSettings } from './components/consumer/ConsumerSettings';
import { MakeTransaction } from './components/consumer/MakeTransaction';

// Admin Components
import { AdminHome } from './components/admin/AdminHome';
import { AdminHistory } from './components/admin/AdminHistory';
import { AdminSettings } from './components/admin/AdminSettings';
import { MakeWorkOrder } from './components/admin/MakeWorkOrder';

// Worker Components
import { WorkerHome } from './components/worker/WorkerHome';
import { WorkerHistory } from './components/worker/WorkerHistory';
import { WorkerSettings } from './components/worker/WorkerSettings';
import { WorkOrder } from './components/worker/WorkOrder';

const MainApp: React.FC = () => {
  const { currentUser } = useApp();
  const [currentPage, setCurrentPage] = useState('home');

  if (!currentUser) {
    return <LoginPage />;
  }

  const renderPage = () => {
    // Consumer Pages
    if (currentUser.role === 'consumer') {
      switch (currentPage) {
        case 'home':
          return <ConsumerHome onNavigate={setCurrentPage} />;
        case 'history':
          return <ConsumerHistory />;
        case 'make-transaction':
          return <MakeTransaction onNavigate={setCurrentPage} />;
        case 'settings':
          return <ConsumerSettings />;
        default:
          return <ConsumerHome onNavigate={setCurrentPage} />;
      }
    }

    // Admin Pages
    if (currentUser.role === 'admin') {
      switch (currentPage) {
        case 'home':
          return <AdminHome onNavigate={setCurrentPage} />;
        case 'history':
          return <AdminHistory />;
        case 'make-work-order':
          return <MakeWorkOrder onNavigate={setCurrentPage} />;
        case 'settings':
          return <AdminSettings />;
        default:
          return <AdminHome onNavigate={setCurrentPage} />;
      }
    }

    // Worker Pages
    if (currentUser.role === 'worker') {
      switch (currentPage) {
        case 'home':
          return <WorkerHome onNavigate={setCurrentPage} />;
        case 'history':
          return <WorkerHistory />;
        case 'work-order':
          return <WorkOrder onNavigate={setCurrentPage} />;
        case 'settings':
          return <WorkerSettings />;
        default:
          return <WorkerHome onNavigate={setCurrentPage} />;
      }
    }

    return null;
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30">
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />
      
      <main className="flex-1 lg:ml-0">
        <div className="pt-16 lg:pt-0 p-6 max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {renderPage()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainApp />
      <Toaster position="top-center" richColors />
    </AppProvider>
  );
}